#!/usr/bin/env python3
"""wolf_gm.py — 狼人杀 9 人局全自动裁判（以房主/roomAgent 身份运行）。

用法：
  python3 wolf_gm.py --room WolfTest \
      --gm-identity ~/Documents/PythonPrj/2026B/Chat/TestAgents/WilsonMacM4Max_TestAgent_001 \
      --players-dir ~/Documents/PythonPrj/2026B/Chat/TestAgents \
      [--seed 42] [--fast] [--gm-manual] [--create-room] [--url https://webharness.chat]

--players-dir：扫描其下子目录（取 username 文件），按目录名排序取 9 个非 GM 身份。
--gm-manual：降级模式，只发 cue 不动服务端权限（权限治理失败时人工主持用）。
流程详见 .kiro/specs/werewolf9/requirements.md。
"""
from __future__ import annotations

import argparse
import json
import random
import signal
import sys
import time
from collections import Counter
from pathlib import Path

from wh_client import ApiError, WhClient, Message, setup_logging
import wolf_protocol as P

log = setup_logging()

WOLF, SEER, WITCH, HUNTER, VILLAGER = "狼人", "预言家", "女巫", "猎人", "平民"
GODS = (SEER, WITCH, HUNTER)
BC = "【狼人杀】"
WOLVES_GROUP = "wolves"    # 狼人群：成员发 #wolves 自动展开给同伴+裁判

FAST = dict(speech=20, night=20, vote=15, last_words=15, ack=15, pk=15, shoot=20)
NORMAL = dict(speech=180, night=120, vote=60, last_words=120, ack=60, pk=60, shoot=60)


def majority_knife(proposals: dict[str, int]) -> tuple[int | None, str]:
    """狼刀超时裁定：唯一多数提议生效；提议平票或无人提议 = 空刀。"""
    if not proposals:
        return None, "TIMEOUT 无人提议 空刀"
    counts = Counter(proposals.values())
    top = max(counts.values())
    cand = [s for s, c in counts.items() if c == top]
    if len(cand) == 1:
        return cand[0], "TIMEOUT 多数提议"
    return None, "TIMEOUT 提议平票 空刀"


class Player:
    def __init__(self, seat: int, username: str, role: str):
        self.seat, self.username, self.role = seat, username, role
        self.alive = True

    def __repr__(self):
        return f"{self.seat}号({self.username},{self.role}{'' if self.alive else ',出局'})"


class Game:
    def __init__(self, args):
        self.args = args
        self.cfg = FAST if args.fast else NORMAL
        self.rng = random.Random(args.seed)
        self.client = WhClient(args.url, args.gm_identity)
        self.players: list[Player] = []
        self.observers: list[str] = []
        self.protected: set[str] = set()       # 服务端不许禁言的成员（房主/裁判）
        self.day_no = 0
        self.rules_added: list[int] = []       # 本局加的全部 whisper 规则 id（清场用）
        self.night_rule_ids: list[int] = []
        self.witch_potions = {"save": True, "poison": True}
        self.last_id = 0
        self.wolves_group: str | None = None   # 服务器上的狼人群名（建群失败则 None）
        self.timeline: list[dict] = []         # 复盘事件流
        self.history: dict = {"nights": [], "days": []}

    # ---------- 基础 ----------

    def seat_of(self, username: str) -> Player | None:
        for p in self.players:
            if p.username == username:
                return p
        return None

    def alive(self, role: str | None = None) -> list[Player]:
        return [p for p in self.players if p.alive and (role is None or p.role == role)]

    def broadcast(self, content: str) -> None:
        text = f"{BC} {content}"
        for attempt in (1, 2, 3):
            try:
                self.client.post(text)
                log.info("[广播] %s", content)
                return
            except ApiError as e:
                log.error("广播失败(%s/3): %s", attempt, e)
                time.sleep(0.5)

    def cue(self, p: Player, content: str) -> None:
        for attempt in (1, 2):
            try:
                self.client.whisper([p.username], content)
                log.info("[cue→%s号] %s", p.seat, content[:80])
                return
            except ApiError as e:
                log.error("cue %s 失败(%s/2): %s", p.username, attempt, e)
                time.sleep(0.5)

    def record(self, kind: str, **kw) -> None:
        kw["kind"], kw["t"] = kind, time.strftime("%H:%M:%S")
        self.timeline.append(kw)
        log.info("[%s] %s", kind, kw)

    # ---------- 消息泵 ----------

    def sync_watermark(self) -> None:
        msgs = self.client.poll(0)
        self.last_id = max((m.id for m in msgs), default=0)
        log.info("消息水位 id=%s", self.last_id)

    def pump(self, timeout: float, handler):
        """拉消息流直到 handler 返回真值或超时。跳过 streaming/撤回。"""
        deadline = time.time() + timeout
        while True:
            remaining = deadline - time.time()
            if remaining <= 0:
                return None
            wait = int(max(1, min(25, remaining)))
            try:
                msgs = self.client.poll(self.last_id, wait=wait)
            except ApiError as e:
                log.warning("poll 失败重试: %s", e)
                time.sleep(1)
                continue
            for m in msgs:
                self.last_id = m.id
                if m.streaming or m.recalled or m.author == self.client.username:
                    continue
                self._log_message(m)
                r = handler(m)
                if r:
                    return r

    def _log_message(self, m: Message) -> None:
        """全知日志：裁判看得见一切（含玩家间私聊）。"""
        tag = "私聊" if m.whisper else "公开"
        to = f"→{'/'.join(m.whisper_to)}" if m.whisper else ""
        log.info("[收到%s%s] %s: %s", tag, to, m.author, m.content[:120].replace("\n", " "))

    # ---------- 权限治理 ----------

    def governance_enabled(self) -> bool:
        return not self.args.gm_manual

    def set_speak(self, username: str, can: bool) -> None:
        if not self.governance_enabled():
            return
        try:
            self.client.set_permission(username, canSpeak=can)
            log.info("[权限] %s canSpeak=%s", username, can)
        except ApiError as e:
            log.error("set_permission(%s) 失败: %s", username, e)

    def mute_all(self) -> None:
        for m in self.client.members():
            name = m.get("username")
            if name and name not in self.protected:
                self.set_speak(name, False)

    def unmute_all(self) -> None:
        for m in self.client.members():
            name = m.get("username")
            if name and name not in self.protected:
                self.set_speak(name, True)

    def add_rule(self, list_type: str, sender: str, receiver: str, priority: int) -> int | None:
        if not self.governance_enabled():
            return None
        try:
            rid = self.client.add_whisper_rule(list_type, sender, receiver, priority)
            self.rules_added.append(rid)
            log.info("[规则] %s %s→%s p%s id=%s", list_type, sender, receiver, priority, rid)
            return rid
        except ApiError as e:
            log.error("add_whisper_rule 失败: %s", e)
            return None

    def purge_rules(self) -> None:
        """复用旧房间时清掉上局残留的私聊规则（正常结束会清，异常退出会残留）。"""
        if not self.governance_enabled():
            return
        try:
            rules = self.client.whisper_rules()
        except ApiError as e:
            log.warning("读取已有私聊规则失败: %s", e)
            return
        for r in rules:
            try:
                self.client.delete_whisper_rule(int(r.get("id") or 0))
            except (ApiError, ValueError):
                pass
        if rules:
            log.info("[清场] 已清理上局残留的 %d 条私聊规则", len(rules))

    def base_rules(self) -> None:
        self.add_rule("allow", self.client.username, "*", 100)
        self.add_rule("allow", "*", self.client.username, 90)
        self.add_rule("deny", "*", "*", 0)

    def night_rules_on(self) -> None:
        # 狼对之间要双向放行：#wolves 展开后每个狼都会私聊其余同伴（含字母序更大的一侧）
        wolves = self.alive(WOLF)
        for a in wolves:
            for b in wolves:
                if a.username != b.username:
                    rid = self.add_rule("allow", a.username, b.username, 50)
                    if rid:
                        self.night_rule_ids.append(rid)

    def night_rules_off(self) -> None:
        if not self.governance_enabled():
            return
        for rid in list(self.night_rule_ids):
            try:
                self.client.delete_whisper_rule(rid)
            except ApiError as e:
                if e.status != 404:            # 已不存在=目标状态，不算失败
                    log.warning("删夜间规则 %s 失败: %s", rid, e)
            finally:
                if rid in self.rules_added:    # 同步移除，收尾清场不再重复删
                    self.rules_added.remove(rid)
        self.night_rule_ids = []

    def seal_dead(self, p: Player) -> None:
        self.add_rule("deny", p.username, "*", 60)

    def cleanup(self) -> None:
        log.info("[清场] 删除 %s 条规则并恢复全员发言", len(self.rules_added))
        if not self.governance_enabled():
            return
        for rid in list(self.rules_added):
            try:
                self.client.delete_whisper_rule(rid)
            except ApiError as e:
                if e.status != 404:            # 幂等：已不存在即已删除
                    log.warning("删规则 %s 失败: %s", rid, e)
        self.rules_added = []
        if self.wolves_group:
            try:
                self.client.delete_group(self.wolves_group)
                log.info("[清场] 已删除群组 #%s", self.wolves_group)
            except ApiError as e:
                log.warning("删群组 #%s 失败: %s", self.wolves_group, e)
            self.wolves_group = None
        self.unmute_all()

    # ---------- SETUP ----------

    def setup(self) -> None:
        self.client.login()
        if self.args.create_room:
            self.client.room = self.args.room
            info = self.client.call("POST", "/api/rooms", {"roomName": self.args.room})
            log.info("建房: created=%s", info.get("created"))
        else:
            self.client.join(self.args.room)
        log.info("已进入房间 %s（身份 %s）", self.args.room, self.client.username)

        try:
            detail = self.client.room_detail()
        except ApiError as e:
            log.warning("读取房间详情失败，受保护名单只含裁判自己: %s", e)
            detail = {}
        # 服务端拒绝限制房主与 roomAgent，禁言循环直接跳过，避免 403 噪音
        self.protected = {n for n in (detail.get("ownerName"), detail.get("roomAgent"),
                                      self.client.username) if n}

        player_names = self._resolve_players()
        present = {m.get("username") for m in self.client.members()}
        if not set(player_names) <= present:
            self._wait_players(set(player_names))
        member_names = [m.get("username") for m in self.client.members() if m.get("username")]
        self.observers = [n for n in member_names
                          if n != self.client.username and n not in player_names]
        for i, name in enumerate(player_names, 1):
            self.players.append(Player(i, name, ""))
        log.info("玩家: %s；旁观者: %s", self.players, self.observers)

        self.sync_watermark()
        self.broadcast(
            f"9人屠边局开始：3狼 + 预言家/女巫/猎人 + 3平民。狼人杀光神职或平民即胜。\n"
            f"座位表：{'，'.join(f'{p.seat}号={p.username}' for p in self.players)}\n"
            f"参数：发言{self.cfg['speech']}s 夜晚{self.cfg['night']}s 投票{self.cfg['vote']}s"
            + ("（快速测试模式）" if self.args.fast else ""))
        self.mute_all()
        self.purge_rules()
        self.base_rules()

        deck = [WOLF] * 3 + [SEER, WITCH, HUNTER] + [VILLAGER] * 3
        self.rng.shuffle(deck)
        wolves = []
        for p, role in zip(self.players, deck):
            p.role = role
            if role == WOLF:
                wolves.append(p)
        for p in self.players:
            card = (f"【角色】你是 {p.seat} 号，角色：{p.role}。"
                    f"请私聊回复我：收到")
            if p.role == WOLF:
                mates = "、".join(f"{w.seat}号({w.username})" for w in wolves if w is not p)
                card += f"。队友：{mates}。夜里可在群里发 #wolves 商议（同伴和裁判都可见）"
            self.cue(p, card)
        self.record("deal", roles={p.username: p.role for p in self.players},
                    seed=self.args.seed)

        self._collect_acks()
        self._setup_wolves_group(wolves)

    def _setup_wolves_group(self, wolves: list[Player]) -> None:
        """在服务器登记狼人群（#wolves 展开给同伴+裁判）。失败只降级不阻断开局。"""
        self.wolves_group = None
        if not wolves:
            return
        members = [self.client.username] + [w.username for w in wolves]
        try:
            self.client.create_group(WOLVES_GROUP, members)
            self.wolves_group = WOLVES_GROUP
            log.info("[群组] 已创建 #%s（%d 人）", WOLVES_GROUP, len(members))
        except ApiError as e:
            if e.status == 409:                 # 上局残留：复用并刷新名单
                try:
                    self.client.update_group(WOLVES_GROUP, members)
                    self.wolves_group = WOLVES_GROUP
                    log.info("[群组] 复用已有 #%s 并刷新名单", WOLVES_GROUP)
                except ApiError as e2:
                    log.warning("群组名单刷新失败，狼人改用逐个私聊: %s", e2)
            else:
                log.warning("创建 #%s 失败（服务器不支持群组？），狼人改用逐个私聊: %s",
                            WOLVES_GROUP, e)

    def _resolve_players(self) -> list[str]:
        if self.args.players:
            names = [n.strip() for n in self.args.players.split(",") if n.strip()]
        else:
            root = Path(self.args.players_dir).expanduser()
            names = sorted((d / "username").read_text().strip()
                           for d in root.iterdir() if (d / "username").exists())
        names = [n for n in names if n != self.client.username]
        if len(names) < 9:
            raise SystemExit(f"玩家不足 9 人：{names}")
        return names[:9]

    def _wait_players(self, wanted: set[str]) -> None:
        """场景 A（裁判建房）：等 9 名玩家全部进房后再开局。"""
        limit = 60 if self.args.fast else 300
        deadline = time.time() + limit
        log.info("等待玩家进房（%s 秒上限）…", limit)
        while time.time() < deadline:
            present = {m.get("username") for m in self.client.members()}
            if wanted <= present:
                return
            time.sleep(2)
        missing = wanted - {m.get("username") for m in self.client.members()}
        raise SystemExit(f"玩家未齐（缺 {missing}），放弃开局")

    def _collect_acks(self) -> None:
        acked: set[str] = set()
        deadline = self.cfg["ack"]
        for round_no in (1, 2):
            self.pump(deadline, lambda m: acked.add(m.author)
                      if m.whisper and m.to(self.client.username)
                      and P.parse_received(m.content) and self.seat_of(m.author) else None)
            missing = [p for p in self.players if p.username not in acked]
            if not missing:
                break
            log.warning("未确认角色卡: %s（重cue一次）", [p.seat for p in missing])
            for p in missing:
                self.cue(p, "【角色】请确认收到你的角色卡。回复：收到")
            deadline = self.cfg["ack"] // 2 or 5
        still = [p.seat for p in self.players if p.username not in acked]
        if still:
            log.warning("TIMEOUT 角色卡仍未确认: %s 号，继续游戏", still)

    # ---------- NIGHT ----------

    def night(self) -> None:
        self.day_no += 1
        n = self.day_no
        night_state: dict = {"n": n}
        self.broadcast(f"天黑请闭眼（第 {n} 夜）")
        self.mute_all()
        self.night_rules_on()

        knife = self._wolf_phase(n)
        check = self._seer_phase(n)
        saved, poison = self._witch_phase(n, knife)
        self.night_rules_off()

        night_state.update(knife=knife, saved=saved, poison=poison)
        deaths: list[tuple[Player, str]] = []      # (死者, 死因)——毒杀记 "poison"，猎人不可开枪
        knife_player = self._alive_by_seat(knife) if knife else None
        if knife_player and not saved:
            deaths.append((knife_player, "night"))
        if poison:
            pp = self._alive_by_seat(poison)
            if pp and all(p is not pp for p, _ in deaths):
                deaths.append((pp, "poison"))
        night_state["deaths"] = [p.seat for p, _ in deaths]
        self.history["nights"].append(night_state)

        if deaths:
            dead_txt = "、".join(f"{p.seat}号" for p, _ in deaths)
            self.broadcast(f"天亮了（第 {n} 天），昨晚 {dead_txt} 死亡")
        else:
            self.broadcast(f"天亮了（第 {n} 天），昨晚是平安夜")
        for p, cause in deaths:
            self._die(p, cause=cause, can_last_words=(n == 1))

    def _alive_by_seat(self, seat: int) -> Player | None:
        for p in self.players:
            if p.seat == seat and p.alive:
                return p
        return None

    def _wolf_phase(self, n: int) -> int | None:
        wolves = self.alive(WOLF)
        if not wolves:
            return None
        if self.wolves_group:
            try:
                self.client.post(
                    f"#wolves 【狼人】第{n}夜。在群里商议，然后发：刀 N（N 为存活座位号）；也可私聊我。")
                log.info("[cue→#wolves] 第%d夜", n)
            except ApiError as e:
                log.warning("群发狼人 cue 失败，退回逐个私聊: %s", e)
                for w in wolves:
                    self.cue(w, f"【狼人】第{n}夜。可与队友私聊商议，然后回复我：刀 N（N 为存活座位号）")
        else:
            for w in wolves:
                self.cue(w, f"【狼人】第{n}夜。可与队友私聊商议，然后回复我：刀 N（N 为存活座位号）")
        proposals: dict[str, int] = {}
        names = {w.username for w in wolves}

        def h(m: Message):
            if m.whisper and m.to(self.client.username) and m.author in names:
                seat = P.parse_knife(m.content)
                if seat and self._alive_by_seat(seat):
                    proposals[m.author] = seat
            if len(proposals) == len(wolves):
                counts = Counter(proposals.values())
                if len(counts) == 1:
                    return next(iter(counts))
            return None

        agreed = self.pump(self.cfg["night"], h)
        if agreed:
            self.record("wolf_knife", night=n, target=agreed, unanimous=True,
                        votes=proposals)
            return agreed
        target, note = majority_knife(proposals)
        self.record("wolf_knife", night=n, target=target, unanimous=False,
                    votes=proposals, note=note)
        return target

    def _seer_phase(self, n: int) -> dict | None:
        seers = self.alive(SEER)
        if not seers:
            return None
        seer = seers[0]
        self.cue(seer, f"【查验】第{n}夜。回复我：查 N（N 为存活座位号）")
        result_box: dict = {}

        def h(m: Message):
            if m.whisper and m.to(self.client.username) and m.author == seer.username:
                seat = P.parse_check(m.content)
                if seat and self._alive_by_seat(seat):
                    target = self._alive_by_seat(seat)
                    is_wolf = target.role == WOLF
                    result_box.update(seat=seat, wolf=is_wolf)
                    return target
            return None

        target = self.pump(self.cfg["night"], h)
        if not target:
            self.record("seer", night=n, note="TIMEOUT 未验人")
            return None
        verdict = "狼人" if result_box["wolf"] else "好人"
        self.cue(seer, f"【查验结果】{target.seat} 号是【{verdict}】")
        self.record("seer", night=n, by=seer.username, target=target.seat, verdict=verdict)
        return result_box

    def _witch_phase(self, n: int, knife: int | None) -> tuple[bool, int | None]:
        witches = self.alive(WITCH)
        if not witches:
            return False, None
        witch = witches[0]
        kn = f"今晚 {knife} 号被刀" if knife and self._alive_by_seat(knife) else "今晚平安夜（无人被刀）"
        if knife and knife == witch.seat and not self.args.witch_self_save:
            kn += "（被刀的是你自己，不可自救）"
        potions = f"解药{'有' if self.witch_potions['save'] else '无'} 毒药{'有' if self.witch_potions['poison'] else '无'}"
        self.cue(witch, f"【用药】第{n}夜。{kn}。{potions}。回复我：救 / 毒 N / 不用")
        got: dict = {}

        def h(m: Message):
            if m.whisper and m.to(self.client.username) and m.author == witch.username:
                if P.parse_save(m.content):
                    got["action"] = "save"
                    return True
                seat = P.parse_poison(m.content)
                if seat is not None:
                    got.update(action="poison", seat=seat)
                    return True
                if P.parse_no_action(m.content):
                    got["action"] = "none"
                    return True
            return None

        self.pump(self.cfg["night"], h)
        action = got.get("action")
        saved = poison_target = None
        if action == "save":
            if not self.witch_potions["save"]:
                log.warning("女巫无解药却回救，忽略")
            elif knife and self._alive_by_seat(knife):
                if knife == witch.seat and not self.args.witch_self_save:
                    log.warning("女巫试图自救，规则禁止，忽略")
                else:
                    saved = True
                    self.witch_potions["save"] = False
            else:
                log.warning("女巫回救但无刀口，忽略")
        elif action == "poison":
            seat = got.get("seat")
            if self.witch_potions["poison"] and seat and self._alive_by_seat(seat):
                poison_target = seat
                self.witch_potions["poison"] = False
            else:
                log.warning("女巫毒 %s 无效（无药/目标不存活），忽略", seat)
        self.record("witch", night=n, action=action, knife=knife,
                    saved=saved, poison=poison_target)
        return bool(saved), poison_target

    # ---------- DAY ----------

    def day(self) -> None:
        self.broadcast(f"第 {self.day_no} 天：进入白天议程")
        self._speech_round(order=[p for p in self.players if p.alive])
        self._vote_phase()

    def _speech_round(self, order: list[Player]) -> None:
        if not order:
            return
        shuffled = order[:]
        self.rng.shuffle(shuffled)
        seq = " → ".join(f"{p.seat}号" for p in shuffled)
        self.broadcast(f"发言顺序：{seq}（每人限时 {self.cfg['speech']}s，说\"完毕\"结束，\"过\"跳过）")
        for p in shuffled:
            if not p.alive:
                continue
            self.set_speak(p.username, True)
            self.broadcast(f"发言环节：轮到 {p.seat}号 {p.username}")
            self.cue(p, f"【发言】轮到你公开发言（限时 {self.cfg['speech']}s）。"
                        f"结束说\"完毕\"，跳过公开发\"过\"。")
            self._wait_speech_end(p, self.cfg["speech"])
            self.set_speak(p.username, False)

    def _wait_speech_end(self, p: Player, seconds: int) -> None:
        spoke = False

        def h(m: Message):
            nonlocal spoke
            if not m.whisper and m.author == p.username:
                spoke = True
                if P.parse_speech_done(m.content):
                    return True
            return None

        done = self.pump(seconds, h)
        if not done:
            self.record("speech", seat=p.seat, note="TIMEOUT" if spoke else "TIMEOUT 零发言")
        else:
            self.record("speech", seat=p.seat, note="完毕/过")

    def _vote_phase(self) -> list[Player]:
        alive = [p for p in self.players if p.alive]
        self.broadcast(f"投票环节开始：公开发送 投票 N（N 为存活座位号）或 弃票（限时 {self.cfg['vote']}s/人）")
        for p in alive:
            self.set_speak(p.username, True)
            self.cue(p, f"【投票】请公开发送：投票 N 或 弃票")
        votes = self._collect_votes(alive, valid=None)
        for p in alive:
            self.set_speak(p.username, False)
        self.history.setdefault("votes", []).append({"day": self.day_no, "votes": votes})
        exiled = self._resolve_votes(votes, alive)
        return exiled

    def _collect_votes(self, voters: list[Player], valid: list[int] | None) -> dict[str, object]:
        votes: dict[str, int | str] = {}

        def h(m: Message):
            if m.whisper or self.seat_of(m.author) is None:
                return None
            p = self.seat_of(m.author)
            if p not in voters or p.username in votes:
                return None
            v = P.parse_vote(m.content)
            if v is None:
                return None
            if isinstance(v, int) and valid is not None and v not in valid:
                return None
            votes[p.username] = v
            if len(votes) == len(voters):
                return True
            return None

        self.pump(self.cfg["vote"] * max(1, len(voters)), h)
        missing = [p.seat for p in voters if p.username not in votes]
        if missing:
            self.record("vote", note=f"TIMEOUT 弃票 {missing}")
            for p in voters:
                votes.setdefault(p.username, "ABSTAIN")
        self.record("vote", votes=votes)
        return votes

    def _resolve_votes(self, votes: dict, voters: list[Player]) -> list[Player]:
        counts = Counter(v for v in votes.values() if isinstance(v, int))
        if not counts:
            self.broadcast("无人得票，今日无人出局")
            return []
        top = max(counts.values())
        cand = sorted(seat for seat, c in counts.items() if c == top)
        self.broadcast(f"计票：{'，'.join(f'{s}号={c}票' for s, c in sorted(counts.items()))}")
        if len(cand) == 1:
            return self._exile(self._alive_by_seat(cand[0]))
        self.broadcast(f"平票：{'、'.join(f'{s}号' for s in cand)} 进入 PK")
        tie = [self._alive_by_seat(s) for s in cand if self._alive_by_seat(s)]
        for p in tie:
            self.set_speak(p.username, True)
            self.broadcast(f"PK 发言：{p.seat}号 {p.username}（限时 {self.cfg['pk']}s）")
            self.cue(p, f"【发言】PK 发言（限时 {self.cfg['pk']}s）。结束说\"完毕\"。")
            self._wait_speech_end(p, self.cfg["pk"])
            self.set_speak(p.username, False)
        alive = [p for p in self.players if p.alive]
        for p in alive:
            self.set_speak(p.username, True)
            self.cue(p, f"【投票】PK 再投：公开发送 投票 N（只能投 {'、'.join(str(s.seat) for s in tie)}）")
        votes2 = self._collect_votes(alive, valid=[p.seat for p in tie])
        for p in alive:
            self.set_speak(p.username, False)
        counts2 = Counter(v for v in votes2.values() if isinstance(v, int))
        if counts2:
            top2 = max(counts2.values())
            cand2 = sorted(s for s, c in counts2.items() if c == top2)
            if len(cand2) == 1:
                self.broadcast(f"PK 计票：{'，'.join(f'{s}号={c}票' for s, c in sorted(counts2.items()))}")
                return self._exile(self._alive_by_seat(cand2[0]))
        self.broadcast("PK 仍平票，今日无人出局")
        return []

    def _exile(self, p: Player | None) -> list[Player]:
        if not p:
            return []
        self.broadcast(f"{p.seat}号 {p.username} 被放逐出局")
        return self._die(p, cause="exile", can_last_words=True)

    # ---------- 死亡 / 猎人 / 胜负 ----------

    def _die(self, p: Player, cause: str, can_last_words: bool) -> list[Player]:
        p.alive = False
        self.record("death", seat=p.seat, username=p.username, cause=cause,
                    role=p.role)
        self.seal_dead(p)
        extra: list[Player] = []
        if can_last_words:
            self._last_words(p)
        if p.role == HUNTER and cause != "poison":
            extra = self._hunter_shoot(p)
        return [p] + extra

    def _last_words(self, p: Player) -> None:
        self.set_speak(p.username, True)
        self.broadcast(f"{p.seat}号遗言（限时 {self.cfg['last_words']}s）")
        self.cue(p, f"【遗言】你已出局。限时 {self.cfg['last_words']}s 公开发表遗言，说\"完毕\"结束。")
        self._wait_speech_end(p, self.cfg["last_words"])
        self.set_speak(p.username, False)

    def _hunter_shoot(self, hunter: Player) -> list[Player]:
        self.broadcast(f"{hunter.seat}号是猎人，可开枪")
        self.cue(hunter, f"【开枪】你可带走一人。回复我：枪 N 或 不开")
        got: dict = {}

        def h(m: Message):
            if m.whisper and m.to(self.client.username) and m.author == hunter.username:
                if P.parse_no_shoot(m.content):
                    got["shot"] = None
                    return True
                seat = P.parse_shoot(m.content)
                if seat and self._alive_by_seat(seat):
                    got["shot"] = seat
                    return True
            return None

        self.pump(self.cfg["shoot"], h)
        seat = got.get("shot")
        if seat is None:
            self.record("hunter", by=hunter.username, note="不开枪或 TIMEOUT")
            self.broadcast(f"{hunter.seat}号猎人未开枪")
            return []
        target = self._alive_by_seat(seat)
        self.broadcast(f"{hunter.seat}号猎人开枪带走 {target.seat}号")
        return self._die(target, cause="shot", can_last_words=False)

    def check_win(self) -> str | None:
        if not self.alive(WOLF):
            return "GOOD"
        living = self.alive()
        if all(p.role not in GODS for p in living) or all(p.role != VILLAGER for p in living):
            return "WOLF"
        return None

    # ---------- END ----------

    def end(self, winner: str) -> None:
        side = {"WOLF": "狼人阵营", "GOOD": "好人阵营", "DRAW": "平局"}.get(winner, winner)
        rows = "；".join(f"{p.seat}号 {p.username}＝{p.role}（{'存活' if p.alive else '出局'}）"
                         for p in self.players)
        self.broadcast(f"游戏结束：{side}获胜！\n身份复盘：{rows}")
        self.record("end", winner=winner)
        self.cleanup()
        state = {
            "room": self.args.room, "seed": self.args.seed, "winner": winner,
            "players": [{"seat": p.seat, "username": p.username, "role": p.role,
                         "alive": p.alive} for p in self.players],
            "timeline": self.timeline, "history": self.history,
            "finished_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
        out = Path(self.args.state_out)
        out.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        log.info("复盘已写入 %s", out)

    # ---------- 主循环 ----------

    def run(self) -> None:
        self.setup()
        winner = None
        stale = 0
        while winner is None:
            # 阶段级容错：单个阶段抛异常（网络/权限等）不终止整局，
            # 缺省规则兜底（超时=弃票/空刀/神职放弃），游戏继续。
            before = sum(1 for p in self.players if p.alive)
            try:
                self.night()
            except Exception:
                log.exception("夜阶段异常，按缺省结果继续")
            winner = self.check_win()
            if winner:
                break
            try:
                self.day()
            except Exception:
                log.exception("白天阶段异常，按缺省结果继续")
            winner = self.check_win()
            if winner:
                break
            # 无进展保护：空刀 + 全弃票会让夜↔天无限循环，连续 3 轮无任何
            # 死亡/放逐即判平局收场（缺省规则写进 rules.md §3b）。
            after = sum(1 for p in self.players if p.alive)
            if after < before:
                stale = 0
                continue
            stale += 1
            log.warning("连续 %d 轮无进展（无死亡、无放逐）", stale)
            if stale >= 3:
                winner = "DRAW"
                self.broadcast("连续多轮无进展（无死亡、无放逐），判定平局，游戏结束")
        self.end(winner)


def _on_sigterm(signum: int, frame: object) -> None:
    raise KeyboardInterrupt


def main() -> None:
    ap = argparse.ArgumentParser(description="狼人杀 9 人局裁判")
    ap.add_argument("--room", default="WolfTest")
    ap.add_argument("--url", default="https://webharness.chat")
    ap.add_argument("--gm-identity", required=True, help="裁判身份目录（含 username/agent_private.pem）")
    ap.add_argument("--players-dir", default=None, help="玩家身份根目录（扫描 username 文件）")
    ap.add_argument("--players", default=None, help="逗号分隔的 9 个玩家用户名（优先于 --players-dir）")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--fast", action="store_true", help="测试时限")
    ap.add_argument("--gm-manual", action="store_true", help="降级：只 cue 不动服务端权限")
    ap.add_argument("--create-room", action="store_true", help="房间不存在时由裁判创建（否则 join 失败退出）")
    ap.add_argument("--witch-self-save", action="store_true", help="允许女巫自救")
    ap.add_argument("--state-out", default="game_state.json")
    args = ap.parse_args()
    if args.seed is None:
        args.seed = int(time.time())
    game = Game(args)
    # pkill/kill 发 SIGTERM：转成 KeyboardInterrupt 走清场路径（与 Ctrl+C 同路）
    signal.signal(signal.SIGTERM, _on_sigterm)
    try:
        game.run()
    except KeyboardInterrupt:
        log.warning("手动中断，尝试清场恢复…")
        game.cleanup()
        sys.exit(130)
    except Exception:
        log.exception("裁判异常退出，尝试清场恢复…")
        try:
            game.cleanup()
        except Exception:
            log.exception("清场也失败，房间可能残留规则/群组，建议换新房间名重开")
        sys.exit(1)


if __name__ == "__main__":
    main()