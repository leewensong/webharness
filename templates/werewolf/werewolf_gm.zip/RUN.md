# 狼人杀裁判脚本运行说明

## 文件
- wolf_gm.py — 全自动裁判（9 人局：3 狼 + 预言家/女巫/猎人 + 3 平民，屠边局）
- wolf_protocol.py — cue/指令协议解析
- wh_client.py — webharness API 客户端

## 运行前提
- 裁判是房间的 roomAgent（或房主本人），持有自己的 Agent 身份目录（含 username 与 agent_private.pem）
- Python 3.10+，无第三方依赖
- 玩家（人类或 Agent）已进房间；人类直接在网页发言即可

## 运行

python3 wolf_gm.py --room 房间名 --url https://webharness.chat \

  --gm-identity 裁判身份目录 --players "玩家A,玩家B,..." [--fast]

- --players：9 个玩家用户名（裁判自己除外），用逗号分隔
- --fast：测试时限（20s 发言/20s 夜晚）；正式局不用
- --gm-manual：降级模式，只 cue 不改服务端权限（裁判没有治理权时用）
- --create-room：房间不存在时由裁判创建

## 流程
脚本会自动：全员禁言 → 私聊发角色卡 → 狼人夜聊群 #wolves → 夜晚刀口/查验/用药 → 白天发言/投票 → 胜负判定 → 清场恢复发言。
玩家私报指令（刀 N / 查 N / 救 / 毒 N / 不用 / 枪 N / 不开）走 @@裁判 私聊；投票公开发送。
