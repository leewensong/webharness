#!/usr/bin/env python3
"""wh_client.py — WebHarness API 客户端（狼人杀项目共用）。

零第三方依赖（标准库 + openssl 命令行）。身份目录约定与 ~/.webharness/wh_agent.py 一致：
  <身份目录>/username + agent_private.pem

用法：
  from wh_client import WhClient, Message
  c = WhClient("https://webharness.chat", "/path/to/identity")
  c.login()
  c.join("WolfTest")
  c.post("大家好")
  c.whisper(["userB", "userC"], "只给你们看")
  msgs = c.poll(after_id, wait=25)
  c.set_permission("userB", canSpeak=False)
  rid = c.add_whisper_rule("deny", "*", "*", 0)
"""
from __future__ import annotations

import base64
import fcntl
import json
import os
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_URL = "https://webharness.chat"
CALL_GAP = 0.3          # 相邻 API 调用最小间隔（服务端无速率文档，保守限速）
MAX_RETRIES = 5


@dataclass
class Message:
    id: int
    author: str
    content: str
    whisper: bool
    whisper_to: list[str] = field(default_factory=list)   # 接收者用户名列表（保序）
    recalled: bool = False
    streaming: bool = False
    raw: dict = field(default_factory=dict)

    def to(self, username: str) -> bool:
        """这条私聊是否发给 username。"""
        return username in self.whisper_to


class ApiError(RuntimeError):
    def __init__(self, status: int, detail: str, path: str = ""):
        super().__init__(f"HTTP {status} {path}: {detail}")
        self.status = status
        self.detail = detail


class WhClient:
    def __init__(self, url: str, identity_dir: str | Path, call_gap: float = CALL_GAP):
        self.url = (url or DEFAULT_URL).rstrip("/")
        self.home = Path(identity_dir).expanduser().resolve()
        self.username = (self.home / "username").read_text().strip()
        self.key_path = self.home / "agent_private.pem"
        self.token: str | None = None
        self._last_call = 0.0
        self._call_gap = call_gap

    # ---------- 底层 HTTP ----------

    def _throttle(self) -> None:
        gap = self._call_gap - (time.time() - self._last_call)
        if gap > 0:
            time.sleep(gap)
        self._last_call = time.time()

    def _raw(self, method: str, path: str, body=None, timeout: float = 15,
             retry: int = MAX_RETRIES) -> tuple[int, dict]:
        self._throttle()
        data = None if body is None else json.dumps(body, ensure_ascii=False).encode()
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = urllib.request.Request(self.url + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as res:
                raw = res.read().decode()
                return res.status, (json.loads(raw) if raw else {})
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode(errors="replace")
            try:
                payload = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                payload = {"detail": raw}
            if not isinstance(payload, dict):
                payload = {"detail": raw}
            return exc.code, payload
        except (urllib.error.URLError, ConnectionError, OSError):
            # 网络瞬断：指数退避重试
            if retry > 0:
                time.sleep(1 + (MAX_RETRIES - retry))
                return self._raw(method, path, body, timeout, retry - 1)
            return 0, {"detail": "network unreachable"}

    def call(self, method: str, path: str, body=None, timeout: float = 15) -> dict:
        """带 401 自动重登的调用；4xx 语义错误抛 ApiError。"""
        code, payload = self._raw(method, path, body, timeout)
        if code == 401 and self.token:            # token 失效 → 重登一次
            self.login()
            code, payload = self._raw(method, path, body, timeout)
        if code >= 400:
            raise ApiError(code, str(payload.get("detail") or payload), path)
        if code == 0:
            raise ApiError(0, str(payload.get("detail") or "network"), path)
        return payload

    # ---------- 认证 ----------

    def _sign(self, nonce: str) -> str:
        with tempfile.NamedTemporaryFile("w", delete=False) as t:
            t.write(nonce)
            nf = t.name
        try:
            raw = subprocess.check_output(
                ["openssl", "pkeyutl", "-sign", "-inkey", str(self.key_path), "-rawin", "-in", nf]
            )
        finally:
            os.unlink(nf)
        return base64.b64encode(raw).decode()

    def login(self) -> str:
        # challenge 按账号一次性：同身份多进程并发登录会互作废 nonce，本地锁串行化
        lock_path = self.home / ".auth.lock"
        with lock_path.open("a+") as lock:
            os.chmod(lock_path, 0o600)
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            try:
                nonce = self.call_raw_noauth("POST", "/api/agent-auth/challenge",
                                             {"username": self.username})["nonce"]
                self.token = self.call_raw_noauth(
                    "POST", "/api/agent-auth/login",
                    {"username": self.username, "signature": self._sign(nonce)})["token"]
            finally:
                fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        return self.token

    def call_raw_noauth(self, method: str, path: str, body) -> dict:
        code, payload = self._raw(method, path, body)
        if code >= 400 or code == 0:
            raise ApiError(code, str(payload.get("detail") or payload), path)
        return payload

    # ---------- 房间 ----------

    def room_detail(self) -> dict:
        return self.call("GET", f"/api/rooms/{self.room}")

    def join(self, room: str, password: str | None = None) -> dict:
        """加入已有房间（POST /api/rooms 兼具创建/加入语义）。绝不新建：房间不存在时
        服务端返回 404，原样抛出（纪律同 wh_agent.py）。密码房需传 password。"""
        self.room = room
        body = {"roomName": room}
        if password:
            body["password"] = password
        joined = self.call("POST", "/api/rooms", body)
        return {"joined": True, "created": bool(joined.get("created")), "info": joined}

    def members(self) -> list[dict]:
        return self.call("GET", f"/api/rooms/{self.room}/members").get("members") or []

    # ---------- 消息 ----------

    def post(self, content: str) -> Message:
        sent = self.call("POST", f"/api/rooms/{self.room}/messages", {"content": content})
        return self._to_message(sent)

    def whisper(self, targets: list[str], content: str) -> Message:
        prefix = "".join(f"@@{t} " for t in targets)   # 协议：双 @@ 前缀 = 私聊
        return self.post(prefix + content)

    def poll(self, after_id: int, wait: int = 25) -> list[Message]:
        query = f"afterId={after_id}&wait={wait}" if after_id else "limit=50"
        payload = self.call("GET", f"/api/rooms/{self.room}/messages?{query}",
                            timeout=wait + 10)
        return [self._to_message(m) for m in (payload.get("messages") or [])]

    @staticmethod
    def _to_message(m: dict) -> Message:
        wto = [w.get("username") for w in (m.get("whisperTo") or []) if w.get("username")]
        return Message(
            id=int(m.get("id") or 0),
            author=m.get("username") or "",
            content=m.get("content") or "",
            whisper=bool(m.get("whisper")),
            whisper_to=wto,
            recalled=bool(m.get("recalled")),
            streaming=bool(m.get("streaming")),
            raw=m,
        )

    # ---------- 治理（房主/roomAgent 专用） ----------

    def set_permission(self, username: str, canSpeak: bool | None = None,
                       canUpload: bool | None = None, canViewHistory: bool | None = None) -> dict:
        body = {k: v for k, v in (("canSpeak", canSpeak), ("canUpload", canUpload),
                                  ("canViewHistory", canViewHistory)) if v is not None}
        return self.call("PUT", f"/api/rooms/{self.room}/permissions/{username}", body)

    def add_whisper_rule(self, list_type: str, sender: str, receiver: str, priority: int = 0) -> int:
        rule = self.call("POST", f"/api/rooms/{self.room}/whisper-rules",
                         {"listType": list_type, "sender": sender, "receiver": receiver,
                          "priority": priority})
        return int(rule.get("id") or 0)

    def delete_whisper_rule(self, rule_id: int) -> None:
        self.call("DELETE", f"/api/rooms/{self.room}/whisper-rules/{rule_id}")

    def whisper_rules(self) -> list[dict]:
        return self.call("GET", f"/api/rooms/{self.room}/whisper-rules").get("rules") or []

    def patch_room(self, **body) -> dict:
        return self.call("PATCH", f"/api/rooms/{self.room}", body)

    # ---------- 房间模板（v2.9） ----------

    def templates(self) -> list[dict]:
        return self.call("GET", "/api/room-templates").get("templates") or []

    def create_template(self, name: str, title: str, description: str = "",
                        rules: str = "", script_name: str | None = None,
                        script_path: str | Path | None = None) -> dict:
        script_b64 = base64.b64encode(Path(script_path).read_bytes()).decode() if script_path else None
        body = {"name": name, "title": title, "description": description, "rules": rules}
        if script_name:
            body.update({"scriptName": script_name, "scriptBase64": script_b64})
        return self.call("POST", "/api/room-templates", body)

    def update_template(self, name: str, **body) -> dict:
        if "script_path" in body:
            sp = body.pop("script_path")
            if sp is not None:
                body["scriptBase64"] = base64.b64encode(Path(sp).read_bytes()).decode()
        return self.call("PATCH", f"/api/room-templates/{name}", body)

    def delete_template(self, name: str) -> dict:
        return self.call("DELETE", f"/api/room-templates/{name}")

    def download_template_script(self, name: str, out_path: str | Path) -> Path:
        """/script 返回二进制（octet-stream），单独用 urllib 拿原始字节。"""
        headers = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        req = urllib.request.Request(self.url + f"/api/room-templates/{name}/script",
                                     headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=30) as res:
            data = res.read()
        out = Path(out_path)
        out.write_bytes(data)
        return out

    # ---------- 群组（v2.8） ----------

    def create_group(self, name: str, members: list[str]) -> dict:
        return self.call("POST", f"/api/rooms/{self.room}/groups",
                         {"name": name, "members": members})

    def update_group(self, name: str, members: list[str]) -> dict:
        return self.call("PATCH", f"/api/rooms/{self.room}/groups/{name}",
                         {"members": members})

    def delete_group(self, name: str) -> dict:
        return self.call("DELETE", f"/api/rooms/{self.room}/groups/{name}")

    def groups(self) -> list[dict]:
        return self.call("GET", f"/api/rooms/{self.room}/groups").get("groups") or []


# ---------- 小工具 ----------

def setup_logging(log_path: str | Path | None = None):
    import logging
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%H:%M:%S")
    root = logging.getLogger("wolf")
    root.setLevel(logging.INFO)
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    root.addHandler(sh)
    if log_path:
        fh = logging.FileHandler(log_path, encoding="utf-8")
        fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        root.addHandler(fh)
    return root