#!/usr/bin/env python3
"""wolf_protocol.py — 狼人杀消息协议（宽容解析，GM 与 bot 共用）。

GM cue 关键词：【角色】【狼人】【查验】【用药】【发言】【投票】【遗言】【开枪】
玩家私报：收到 / 刀 N / 查 N / 救 / 毒 N / 不用 / 枪 N / 不开
玩家公开：发言正文（完毕|过|pass 收尾）、投票 N、弃票

解析原则：全角/半角数字等价、「N号」等价「N」、忽略空白；多命令只取首个命中。
"""
from __future__ import annotations

import re

DIGITS = str.maketrans("０１２３４５６７８９", "0123456789")

DONE_WORDS = ("完毕", "过", "pass")


def normalize(s: str) -> str:
    """全角数字→半角、去空白、小写化。"""
    return (s or "").translate(DIGITS).replace(" ", "").replace("　", "").lower()


def _num_after(text: str, keyword: str) -> int | None:
    """在规范化文本中取 keyword 之后的整数（容忍 '3号' / '3'）。"""
    m = re.search(keyword + r"(\d+)", text)
    if m:
        return int(m.group(1))
    return None


def parse_received(content: str) -> bool:
    return "收到" in normalize(content)


def parse_knife(content: str) -> int | None:
    return _num_after(normalize(content), "刀")


def parse_check(content: str) -> int | None:
    return _num_after(normalize(content), "查")


def parse_save(content: str) -> bool:
    """「救」但不是「救不了」之类；且不能同时是「毒N」。"""
    t = normalize(content)
    return "救" in t and "毒" not in t


def parse_poison(content: str) -> int | None:
    return _num_after(normalize(content), "毒")


def parse_no_action(content: str) -> bool:
    """「不用」/「不救」/「无毒」/「pass」——放弃用药。"""
    t = normalize(content)
    return ("不用" in t or "不救" in t or "pass" in t or "放弃" in t) and "毒" not in t


def parse_shoot(content: str) -> int | None:
    return _num_after(normalize(content), "枪")


def parse_no_shoot(content: str) -> bool:
    t = normalize(content)
    return "不开" in t or "不枪" in t or "放弃" in t


def parse_vote(content: str) -> int | None | str:
    """返回 int（票）、'ABSTAIN'（弃票）或 None（非投票消息）。"""
    t = normalize(content)
    if re.search(r"弃票|不投|abstain|pass", t):
        return "ABSTAIN"
    n = _num_after(t, "投票")
    if n is None:
        # 宽容：纯数字或「投N」
        m = re.fullmatch(r"投?(\d+)号?", t)
        if m:
            n = int(m.group(1))
    return n


def parse_speech_done(content: str) -> bool:
    """发言结束判定：含 完毕/过/pass。"""
    t = normalize(content)
    return any(w in t for w in DONE_WORDS)


# ---------- bot 侧：识别 GM cue 类型 ----------

# 注意：【查验结果】必须排在【查验】/【狼人】之前——结果文案含「是【狼人】」，
# 否则会被误判成狼人 cue（预言家会去提刀）。
CUE_PATTERNS = [
    ("ROLE", "【角色】"),
    ("CHECK_RESULT", "【查验结果】"),
    ("WOLF", "【狼人】"),
    ("CHECK", "【查验】"),
    ("WITCH", "【用药】"),
    ("SPEECH", "【发言】"),
    ("VOTE", "【投票】"),
    ("LASTWORDS", "【遗言】"),
    ("SHOOT", "【开枪】"),
]


def cue_type(content: str) -> str | None:
    t = normalize(content)
    for kind, tag in CUE_PATTERNS:
        if normalize(tag) in t:
            return kind
    return None


def cue_speech_limit(content: str) -> int | None:
    """从发言 cue 中解析限时秒数（「限时20s」/「限时 20 秒」）。"""
    t = normalize(content)
    m = re.search(r"限时(\d+)(?:s|秒)?", t)
    return int(m.group(1)) if m else None


def cue_role(content: str) -> str | None:
    """从角色卡 cue 解析角色名（「角色：狼人」）。"""
    t = normalize(content)
    m = re.search(r"角色[:：](狼人|预言家|女巫|猎人|平民)", t)
    return m.group(1) if m else None


def cue_seat(content: str) -> int | None:
    """从角色卡 cue 解析「你是 N 号」。"""
    t = normalize(content)
    m = re.search(r"你是(\d+)号", t)
    return int(m.group(1)) if m else None


def cue_teammates(content: str) -> list[int]:
    """从狼人角色卡解析队友座位列表（「队友：5号(xxx)、8号(yyy)」）。"""
    t = normalize(content)
    if "队友" not in t:
        return []
    seg = t.split("队友", 1)[1]
    return [int(n) for n in re.findall(r"(\d+)号", seg)]


def cue_knife_target(content: str) -> int | None:
    """从女巫 cue 解析「今晚 N号 被刀」；无刀口（平安）返回 None 且 cue 含「平安」。"""
    t = normalize(content)
    if "平安" in t:
        return None
    m = re.search(r"今晚(\d+)号被刀", t)
    return int(m.group(1)) if m else None


def is_gm_broadcast(content: str) -> bool:
    """GM 公开广播以【狼人杀】开头。"""
    return normalize(content).startswith("【狼人杀】")